﻿namespace Evently.Api.OpenTelemetry;

public static class DiagnosticsConfig
{
    public const string ServiceName = "Evently";
}
