﻿namespace Evently.Modules.Events.Presentation;

internal static class Tags
{
    internal const string Events = "Events";
    internal const string TicketTypes = "TicketTypes";
    internal const string Categories = "Categories";
}
