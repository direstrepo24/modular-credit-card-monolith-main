﻿namespace Evently.Modules.Attendance.Presentation;

internal static class Permissions
{
    internal const string CheckInTicket = "tickets:check-in";
    internal const string GetEventStatistics = "event-statistics:read";
}
