﻿namespace Evently.Modules.Ticketing.Infrastructure.Database;

internal static class Schemas
{
    internal const string Ticketing = "ticketing";
}
